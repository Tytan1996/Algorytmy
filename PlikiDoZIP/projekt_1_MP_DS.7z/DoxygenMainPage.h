/*!\mainpage Strona glowna
*
*\section intro_sec Wstep
*   <br>**Algorytmy Dynamiczna Tablica**<br>
*   Damian Szopinski 185394<br>
*   Maciej Pestka 170088<br>
*   Szczegolowe informacje znajduja sie w pliku PDF! <br>
*<a href="namespace_ai_s_d.html">Kliknij tutaj by przejsc do dokumentacji funkcji testujacych</a><br>
*<a href="class_ai_s_d_1_1_dynamic_array.html">Kliknij tutaj by przejsc do dokumentacji Dynamic Array</a>
*/
