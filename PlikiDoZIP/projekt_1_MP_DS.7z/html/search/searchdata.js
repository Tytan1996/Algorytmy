var indexSectionsWithContent =
{
  0: "_acdefgilnoprst~",
  1: "dnr",
  2: "a",
  3: "dt",
  4: "_acdefiloprs~",
  5: "gn",
  6: "do",
  7: "t",
  8: "s"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions",
  5: "variables",
  6: "related",
  7: "defines",
  8: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Namespaces",
  3: "Files",
  4: "Functions",
  5: "Variables",
  6: "Friends",
  7: "Macros",
  8: "Pages"
};

