var searchData=
[
  ['grade_0',['grade',['../struct_record.html#a657fc21fa68c7bd678af5417686cbb1d',1,'Record']]]
];
