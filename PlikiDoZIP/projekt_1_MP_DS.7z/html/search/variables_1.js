var searchData=
[
  ['name_0',['name',['../struct_record.html#a2ad017de6628f030e086e682d231d38a',1,'Record']]]
];
