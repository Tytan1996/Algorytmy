#ifndef SOR_H
#define SOR_H


class Sor
{
    public:
        Sor();
        virtual ~Sor();

    protected:

    private:
};

#endif // SOR_H
