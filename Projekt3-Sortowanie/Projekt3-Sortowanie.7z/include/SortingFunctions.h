#ifndef SORTINGFUNCTIONS_H
#define SORTINGFUNCTIONS_H


class SortingFunctions
{
    public:
        SortingFunctions();
        virtual ~SortingFunctions();

    protected:

    private:
};

#endif // SORTINGFUNCTIONS_H
