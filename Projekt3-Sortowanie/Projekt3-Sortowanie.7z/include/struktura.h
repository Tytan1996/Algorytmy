#ifndef STRUKTURA_H
#define STRUKTURA_H


struct Record {
    int key;
    char ID[5];
};

#endif // STRUKTURA_H
