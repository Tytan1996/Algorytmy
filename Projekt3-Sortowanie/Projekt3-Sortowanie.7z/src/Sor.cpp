#include "Sor.h"

Sor::Sor()
{
    //ctor
}

Sor::~Sor()
{
    //dtor
}
