#include "SortingFunctions.h"

SortingFunctions::SortingFunctions()
{
    //ctor
}

SortingFunctions::~SortingFunctions()
{
    //dtor
}
